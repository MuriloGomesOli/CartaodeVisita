package com.example.felizaniversrio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.layout.ContentScale
import com.example.felizaniversrio.ui.theme.FelizAniversárioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FelizAniversárioTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        // 🔹 Fundo preenchendo toda a tela
                        Image(
                            painter = painterResource(id = R.drawable.cores_de_fundo_ef83sn08yxnzfbo5),
                            contentDescription = null, // Apenas decorativo
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        // 🔹 Seção do perfil (centro da tela)
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            ProfileSection()
                        }

                        // 🔹 Seção de contatos (parte inferior)
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(bottom = 32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Bottom
                        ) {
                            ContactSection()
                        }
                    }
                }
            }
        }
    }
}

// 🔹 Seção do perfil: exibe a imagem, nome e cargo
@Composable
fun ProfileSection() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // 🔹 Imagem de perfil com formato circular
        Image(
            painter = painterResource(id = R.drawable.ic_launcher_foreground),
            contentDescription = "Profile Picture",
            modifier = Modifier
                .size(120.dp) // Tamanho aumentado
        )

        // 🔹 Nome
        Text(
            text = "Jennifer Doe",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black
        )

        // 🔹 Cargo
        Text(
            text = "Android Developer Extraordinaire",
            fontSize = 18.sp,
            fontWeight = FontWeight.Normal,
            color = Color(0xFF3DDC84) // Verde Android
        )
    }
}

// 🔹 Seção de contatos: exibe telefone, e-mail e redes sociais
@Composable
fun ContactSection() {
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ContactItem(icon = R.drawable.call_24dp_1f1f1f, text = "+55 11 98112-2847")
        ContactItem(icon = R.drawable.reply_all_24dp_1f1f1f, text = "@socialmidia.com")
        ContactItem(icon = R.drawable.email_24dp_1f1f1f, text = "hawn.g@gmail.com")
    }
}

// 🔹 Item de contato: exibe um ícone e o texto associado
@Composable
fun ContactItem(icon: Int, text: String, modifier: Modifier = Modifier) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.padding(8.dp)
    ) {
        Icon(
            painter = painterResource(id = icon),
            contentDescription = "Contact Icon",
            tint = Color.White, // Ícones brancos
            modifier = Modifier
                .size(30.dp) // Tamanho ajustado
                .padding(end = 12.dp)
        )
        Text(
            text = text,
            fontSize = 20.sp,
            color = Color.Black // Texto branco para contraste
        )
    }
}

// 🔹 Preview para visualizar no Android Studio
@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    FelizAniversárioTheme {
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            // Fundo
            Image(
                painter = painterResource(id = R.drawable.cores_de_fundo_ef83sn08yxnzfbo5),
                contentDescription = null, // Apenas decorativo
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Seção do perfil
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                ProfileSection()
            }

            // Seção de contatos
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom
            ) {
                ContactSection()
            }
        }
    }
}
